import os
import re
import sqlite3
import joblib
import numpy as np
import requests
import json
from flask import Flask, render_template, request, jsonify, g
from sklearn.preprocessing import LabelEncoder

app = Flask(__name__)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH  = os.path.join(BASE_DIR, 'predictions.db')

API_KEY    = "AIzaSyAyGECARB5jHW4IIncCvnFX4oJ5Rz_bHXs"
GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=" + API_KEY

DEP_DIR  = os.path.join(BASE_DIR, 'DepressionModels')
BEH_DIR  = os.path.join(BASE_DIR, 'BehaviouralModel')

DEP_MODEL    = joblib.load(os.path.join(DEP_DIR, 'best_model.pkl'))
DEP_SCALER   = joblib.load(os.path.join(DEP_DIR, 'Scalers.pkl'))
DEP_FEATURES = joblib.load(os.path.join(DEP_DIR, 'selected_features.pkl'))

BEH_MODEL    = joblib.load(os.path.join(BEH_DIR, 'wellbeing_model.pkl'))
BEH_SCALER   = joblib.load(os.path.join(BEH_DIR, 'wellbeing_scaler.pkl'))
BEH_FEATURES = joblib.load(os.path.join(BEH_DIR, 'wellbeing_features.pkl'))

DEP_CAT_COLS = {
    'City': ['Ahmedabad','Bangalore','Bhopal','Chennai','Delhi','Faridabad',
             'Hyderabad','Indore','Jaipur','Kalyan','Kanpur','Kolkata','Lucknow',
             'Ludhiana','Meerut','Mumbai','Nagpur','Nashik','Patna','Pune',
             'Rajkot','Srinagar','Surat','Thane','Vadodara','Varanasi',
             'Visakhapatnam','Other'],
    'Degree': ['B.Com','B.Ed','B.Pharm','B.Tech','BA','BBA','BCA','BE','BSc',
               'Class 12','LLB','M.Tech','MA','MBA','MCA','MCom','MD','ME',
               'MPhil','MSc','PhD','Other'],
    'Sleep Duration': ['5-6 hours','7-8 hours','Less than 5 hours','More than 8 hours'],
    'Dietary Habits': ['Healthy','Moderate','Unhealthy'],
}

_dep_encoders = {}
for col, cats in DEP_CAT_COLS.items():
    le = LabelEncoder()
    le.fit(cats)
    _dep_encoders[col] = le


def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(e=None):
    db = g.pop('db', None)
    if db:
        db.close()


def init_db():
    db = sqlite3.connect(DB_PATH)

    db.execute('''CREATE TABLE IF NOT EXISTS predictions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        age INTEGER,
        gender TEXT,
        prediction TEXT,
        confidence REAL,
        ai_validated INTEGER DEFAULT 0,
        gemini_override INTEGER DEFAULT 0,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )''')

    db.execute('''CREATE TABLE IF NOT EXISTS behavioural_predictions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        daily_screen_time_min REAL,
        num_app_switches REAL,
        sleep_hours REAL,
        notification_count REAL,
        social_media_time_min REAL,
        focus_score REAL,
        mood_score REAL,
        anxiety_level REAL,
        digital_wellbeing_score REAL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )''')

    db.execute('''CREATE TABLE IF NOT EXISTS dataset_clusters (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        acad_pressure REAL,
        fin_stress REAL,
        sleep_val REAL,
        cgpa REAL,
        depression INTEGER,
        cluster_id INTEGER
    )''')

    # --- Run migrations to fix any old/missing columns ---
    dep_cols = [r[1] for r in db.execute("PRAGMA table_info(predictions)").fetchall()]
    for col in ('ai_validated', 'gemini_override'):
        if col not in dep_cols:
            try:
                db.execute("ALTER TABLE predictions ADD COLUMN " + col + " INTEGER DEFAULT 0")
            except Exception:
                pass

    beh_cols = [r[1] for r in db.execute("PRAGMA table_info(behavioural_predictions)").fetchall()]
    for col in ('focus_score', 'mood_score', 'anxiety_level', 'digital_wellbeing_score',
                'num_app_switches', 'sleep_hours', 'notification_count', 'social_media_time_min',
                'daily_screen_time_min'):
        if col not in beh_cols:
            try:
                db.execute("ALTER TABLE behavioural_predictions ADD COLUMN " + col + " REAL DEFAULT 0")
            except Exception:
                pass

    db.commit()
    db.close()


def extract_json(text):
    try:
        return json.loads(text.strip())
    except Exception:
        pass
    match = re.search(r'\{[\s\S]*\}', text)
    if match:
        try:
            return json.loads(match.group())
        except Exception:
            pass
    return None


def call_ai(prompt):
    resp = requests.post(
        GEMINI_URL,
        json={
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": 0.1, "maxOutputTokens": 1200}
        },
        timeout=25
    )
    data = resp.json()
    if 'error' in data:
        raise Exception(data['error'].get('message', 'API error'))
    raw = data['candidates'][0]['content']['parts'][0]['text']
    result = extract_json(raw)
    if result is None:
        raise Exception("Could not parse AI response. Raw: " + raw[:200])
    return result


def critical_override(form):
    suicidal = str(form.get('Have you ever had suicidal thoughts ?', 'No')).strip().lower()
    family   = str(form.get('Family History of Mental Illness', 'No')).strip().lower()
    acad     = float(form.get('Academic Pressure', 0) or 0)
    fin      = float(form.get('Financial Stress', 0) or 0)
    sleep_v  = str(form.get('Sleep Duration', ''))
    sleep_hrs = 6.0
    if 'less' in sleep_v.lower():
        sleep_hrs = 4.0
    elif '7' in sleep_v or '8' in sleep_v:
        sleep_hrs = 7.5
    elif 'more' in sleep_v.lower():
        sleep_hrs = 9.0
    if suicidal in ('yes', '1', 'true'):
        return True
    if family in ('yes', '1', 'true') and (acad >= 4 or fin >= 4):
        return True
    if acad >= 4.5 and fin >= 4.5 and sleep_hrs <= 4:
        return True
    return False


def ai_analyze(form, ml_prediction, ml_confidence):
    lines = [
        "You are a mental health clinical decision support AI.",
        "ML model prediction: Depression=" + str(ml_prediction) + " confidence=" + str(round(ml_confidence, 1)) + "%",
        "Student data:",
        "Age=" + str(form.get('Age', 'N/A')),
        "AcademicPressure=" + str(form.get('Academic Pressure', 'N/A')) + "/5",
        "FinancialStress=" + str(form.get('Financial Stress', 'N/A')) + "/5",
        "CGPA=" + str(form.get('CGPA', 'N/A')),
        "SleepDuration=" + str(form.get('Sleep Duration', 'N/A')),
        "DietaryHabits=" + str(form.get('Dietary Habits', 'N/A')),
        "StudySatisfaction=" + str(form.get('Study Satisfaction', 'N/A')) + "/5",
        "SuicidalThoughts=" + str(form.get('Have you ever had suicidal thoughts ?', 'No')),
        "FamilyHistoryMentalIllness=" + str(form.get('Family History of Mental Illness', 'No')),
        "WorkStudyHoursPerDay=" + str(form.get('Work/Study Hours', 'N/A')),
        "RULE: If SuicidalThoughts=Yes then final_prediction must be Yes and risk_level must be Critical.",
        "Respond with ONLY this JSON object, nothing else before or after it:",
        '{"final_prediction": "Yes", "confidence": 85, "risk_level": "High", "summary": "Write clinical summary here.", "recommendations": ["tip1", "tip2", "tip3", "tip4", "tip5"]}',
        "Fill in correct values based on the student data above."
    ]
    try:
        return call_ai("\n".join(lines))
    except Exception:
        return None


def encode_depression_input(form):
    row = {}
    for feat in DEP_FEATURES:
        if feat in _dep_encoders:
            val = str(form.get(feat, '')).strip()
            try:
                row[feat] = int(_dep_encoders[feat].transform([val])[0])
            except Exception:
                row[feat] = 0
        else:
            try:
                row[feat] = float(form.get(feat, 0) or 0)
            except Exception:
                row[feat] = 0.0
    import pandas as pd
    return DEP_SCALER.transform(pd.DataFrame([row], columns=DEP_FEATURES))


def encode_behavioural_input(form):
    row = {}
    for feat in BEH_FEATURES:
        try:
            row[feat] = float(form.get(feat, 0) or 0)
        except Exception:
            row[feat] = 0.0
    import pandas as pd
    return BEH_SCALER.transform(pd.DataFrame([row], columns=BEH_FEATURES))


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/predict')
def predict_page():
    return render_template('predict.html', dep_features=DEP_FEATURES, dep_cat_cols=DEP_CAT_COLS)


@app.route('/behavioural')
def behavioural_page():
    return render_template('behavioural.html', beh_features=BEH_FEATURES)


@app.route('/recommendations')
def recommendations_page():
    return render_template('recommendations.html')


@app.route('/history')
def history():
    db = get_db()
    rows = db.execute('SELECT * FROM predictions ORDER BY timestamp DESC LIMIT 50').fetchall()
    beh_rows = db.execute('SELECT * FROM behavioural_predictions ORDER BY timestamp DESC LIMIT 50').fetchall()
    return render_template('history.html', rows=rows, beh_rows=beh_rows)


@app.route('/timeline')
def timeline_page():
    return render_template('timeline.html')


@app.route('/clusters')
def clusters_page():
    return render_template('clusters.html')


# ── Depression prediction ──────────────────────────────────────────────────
@app.route('/api/predict', methods=['POST'])
def api_predict():
    try:
        form = request.json or {}
        vec      = encode_depression_input(form)
        pred_idx = DEP_MODEL.predict(vec)[0]
        prob     = DEP_MODEL.predict_proba(vec)[0]

        ml_label = 'Yes' if int(pred_idx) == 1 else 'No'
        ml_conf  = float(np.max(prob)) * 100

        override = critical_override(form)
        if override:
            ml_label = 'Yes'
            ml_conf  = 99.0

        ai_result   = ai_analyze(form, ml_label, ml_conf)
        final_label = ml_label
        final_conf  = ml_conf
        ai_used     = False

        if ai_result:
            ai_used     = True
            final_label = str(ai_result.get('final_prediction', ml_label))
            final_conf  = float(ai_result.get('confidence', ml_conf))
            if override:
                final_label = 'Yes'

        db = get_db()
        db.execute(
            'INSERT INTO predictions (name,age,gender,prediction,confidence,ai_validated,gemini_override) VALUES (?,?,?,?,?,?,?)',
            (form.get('name', 'Anonymous'), form.get('Age', 0), form.get('Gender', ''),
             final_label, round(final_conf, 2), 1 if ai_used else 0, 1 if ai_used else 0)
        )
        db.commit()

        return jsonify({
            'prediction':      final_label,
            'confidence':      round(final_conf, 2),
            'ml_prediction':   ml_label,
            'ml_confidence':   round(ml_conf, 2),
            'ai_used':         ai_used,
            'risk_level':      str(ai_result.get('risk_level', 'High' if final_label == 'Yes' else 'Low')) if ai_result else ('High' if final_label == 'Yes' else 'Low'),
            'summary':         str(ai_result.get('summary', '')) if ai_result else '',
            'recommendations': list(ai_result.get('recommendations', [])) if ai_result else [],
            'probabilities':   {'No': round(float(prob[0])*100,2), 'Yes': round(float(prob[1])*100,2)}
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ── Behavioural prediction ─────────────────────────────────────────────────
@app.route('/api/predict_behavioural', methods=['POST'])
def api_predict_behavioural():
    try:
        form = request.json or {}
        vec   = encode_behavioural_input(form)
        score = float(BEH_MODEL.predict(vec)[0])
        score = round(max(0.0, min(100.0, score)), 2)

        if score >= 75:   label = 'Excellent'
        elif score >= 55: label = 'Good'
        elif score >= 35: label = 'Moderate'
        elif score >= 15: label = 'Poor'
        else:             label = 'Critical'

        db = get_db()
        db.execute(
            '''INSERT INTO behavioural_predictions
               (name, daily_screen_time_min, num_app_switches, sleep_hours,
                notification_count, social_media_time_min, focus_score,
                mood_score, anxiety_level, digital_wellbeing_score)
               VALUES (?,?,?,?,?,?,?,?,?,?)''',
            (
                form.get('name', 'Anonymous'),
                float(form.get('daily_screen_time_min', 0) or 0),
                float(form.get('num_app_switches', 0) or 0),
                float(form.get('sleep_hours', 0) or 0),
                float(form.get('notification_count', 0) or 0),
                float(form.get('social_media_time_min', 0) or 0),
                float(form.get('focus_score', 0) or 0),
                float(form.get('mood_score', 0) or 0),
                float(form.get('anxiety_level', 0) or 0),
                score
            )
        )
        db.commit()
        return jsonify({'score': score, 'label': label})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ── Timeline API — returns behavioural predictions for a user ──────────────
@app.route('/api/timeline/user')
def timeline_user():
    """
    Returns all behavioural predictions for a given name, ordered oldest→newest.
    Each row becomes one point on the timeline chart.
    """
    name = request.args.get('name', '').strip()
    if not name:
        return jsonify({'found': False, 'rows': []})
    db = get_db()
    rows = db.execute(
        '''SELECT id, digital_wellbeing_score, sleep_hours, mood_score,
                  anxiety_level, daily_screen_time_min, social_media_time_min,
                  timestamp
           FROM behavioural_predictions
           WHERE LOWER(name) = LOWER(?)
           ORDER BY timestamp ASC''',
        (name,)
    ).fetchall()
    if not rows:
        return jsonify({'found': False, 'rows': []})
    return jsonify({'found': True, 'rows': [dict(r) for r in rows]})


# ── Clusters API — returns depression predictions for a user ───────────────
@app.route('/api/clusters/user')
def clusters_user():
    """
    Returns all depression predictions for a given name, ordered oldest→newest.
    Used to build the personal cluster view.
    """
    name = request.args.get('name', '').strip()
    if not name:
        return jsonify({'found': False, 'rows': []})
    db = get_db()
    rows = db.execute(
        '''SELECT id, prediction, confidence, age, gender, timestamp
           FROM predictions
           WHERE LOWER(name) = LOWER(?)
           ORDER BY timestamp ASC''',
        (name,)
    ).fetchall()
    if not rows:
        return jsonify({'found': False, 'rows': []})
    return jsonify({'found': True, 'rows': [dict(r) for r in rows]})


# ── Recommendations ────────────────────────────────────────────────────────
@app.route('/api/recommend', methods=['POST'])
def api_recommend():
    try:
        data  = request.json or {}
        lines = [
            "You are a mental health counselor AI.",
            "Give detailed practical mental health recommendations for this student.",
            "Profile:",
            "DepressionRisk=" + str(data.get('prediction', 'Unknown')),
            "RiskLevel=" + str(data.get('risk_level', 'Unknown')),
            "AcademicPressure=" + str(data.get('academic_pressure', 'N/A')) + "/5",
            "FinancialStress=" + str(data.get('financial_stress', 'N/A')) + "/5",
            "SleepQuality=" + str(data.get('sleep', 'N/A')),
            "SuicidalThoughts=" + str(data.get('suicidal', 'No')),
            "FamilyHistory=" + str(data.get('family_history', 'No')),
            "Respond with ONLY this JSON object, nothing else:",
            '{"immediate_actions": ["a1", "a2", "a3"], "lifestyle_changes": ["l1", "l2", "l3", "l4"], "professional_help": ["p1", "p2"], "self_care_tips": ["s1", "s2", "s3", "s4"], "crisis_resources": ["c1", "c2"], "motivational_message": "message here"}',
            "Fill in real personalised content based on the profile above."
        ]
        result = call_ai("\n".join(lines))
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ── Stats / History ────────────────────────────────────────────────────────
@app.route('/api/stats')
def api_stats():
    db    = get_db()
    total = db.execute('SELECT COUNT(*) as c FROM predictions').fetchone()['c']
    dep   = db.execute("SELECT COUNT(*) as c FROM predictions WHERE prediction='Yes'").fetchone()['c']
    nd    = db.execute("SELECT COUNT(*) as c FROM predictions WHERE prediction='No'").fetchone()['c']
    recent = db.execute(
        'SELECT name, prediction, confidence, timestamp FROM predictions ORDER BY timestamp DESC LIMIT 10'
    ).fetchall()
    return jsonify({'total': total, 'depressed': dep, 'not_depressed': nd,
                    'recent': [dict(r) for r in recent]})


@app.route('/api/history')
def api_history():
    db = get_db()
    rows = db.execute('SELECT * FROM predictions ORDER BY timestamp DESC LIMIT 50').fetchall()
    return jsonify([dict(r) for r in rows])


@app.route('/api/history/behavioural')
def api_history_behavioural():
    db = get_db()
    rows = db.execute('SELECT * FROM behavioural_predictions ORDER BY timestamp DESC LIMIT 50').fetchall()
    return jsonify([dict(r) for r in rows])


if __name__ == '__main__':
    init_db()
    app.run(debug=True)
